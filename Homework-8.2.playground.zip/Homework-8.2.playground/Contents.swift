import UIKit

struct Dequeue<Element>{
    
    var dequeue: [Element] = []
    
    init(capacity: Int){
        dequeue.reserveCapacity(capacity)
    }
    mutating func pushFront(element: Element){
        dequeue.insert(element, at: 0)
    }
    mutating func pushBack(element: Element){
        dequeue.append(element)
    }
    mutating func popBack(){
        dequeue.removeLast()
    }
    mutating func popFront(){
        dequeue.remove(at: 0)
    }
    func front() -> Element{
        return dequeue.first!
    }
    func back() -> Element{
        return dequeue.last!
    }
    mutating func Clear(){
        dequeue = []
    }
}
var dq = Dequeue<Int>(capacity: 10)
dq.pushBack(element: 1)
dq.pushFront(element: 2)
dq.pushFront(element: 3)
dq.pushBack(element: 4)
print(dq)
dq.popBack()
dq.popFront()
print(dq)
dq.front()
dq.back()
dq.Clear()
print(dq)
